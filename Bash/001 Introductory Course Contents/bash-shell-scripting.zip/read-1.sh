#!/bin/bash

read NUM

echo "The number inputed by user is $NUM"
