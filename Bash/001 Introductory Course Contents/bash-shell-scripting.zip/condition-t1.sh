#!/bin/bash

count=32

if [ $count -gt 0 ] ; then
	echo "Count is positive"
	printf "My current working directory is \n $PWD \n"
fi
