#!/bin/bash


while read LINE
do
	echo $LINE
done < filename.txt
