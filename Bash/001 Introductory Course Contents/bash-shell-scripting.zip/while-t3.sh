#!/bin/bash


while :
do
	echo "Hello there"
	sleep 1
done
