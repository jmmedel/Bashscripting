#!/bin/bash

array_var=("The" "rate" "is" 45 "per KG")
echo ${array_var[0]}
echo ${array_var[1]}
echo ${array_var[2]}
echo ${array_var[3]}
echo ${array_var[4]}
