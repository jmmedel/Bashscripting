#!/bin/bash

until false
do
	echo "Hi there"
	sleep 1
done
