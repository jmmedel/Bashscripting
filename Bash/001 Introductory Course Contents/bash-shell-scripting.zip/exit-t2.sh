echo "This is from subscript"
exit 0
