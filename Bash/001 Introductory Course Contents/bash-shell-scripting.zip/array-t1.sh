#!/bin/bash

declare -a var

var[0]="Hello"
var[1]="red"
var[2]="Apple"

echo ${var[0]}
echo ${var[1]}
echo ${var[2]}
