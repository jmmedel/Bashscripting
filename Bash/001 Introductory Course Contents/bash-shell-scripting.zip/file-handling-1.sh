#!/bin/bash


cat filename.txt | while read LINE
do
	echo $LINE
done
