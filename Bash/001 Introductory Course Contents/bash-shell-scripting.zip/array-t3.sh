#!/bin/bash

array_var=([0]="First item" [1]="Second item" Last_item)
echo ${array_var[0]}
echo ${array_var[1]}
echo ${array_var[2]}
