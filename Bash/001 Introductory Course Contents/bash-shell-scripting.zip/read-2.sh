#!/bin/bash

read -n2 NUM

echo "The number inputed by user is $NUM"
