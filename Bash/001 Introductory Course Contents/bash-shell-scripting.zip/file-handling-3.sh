#!/bin/bash


while input_file= read LINE
do
	echo $LINE
done < filename.txt
